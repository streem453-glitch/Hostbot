import asyncio
import json
import logging
import os
import re
import signal
import sys
import time
import uuid
from pathlib import Path
from typing import Any

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery, Document, InlineKeyboardButton, InlineKeyboardMarkup,
    Message
)
from cryptography.fernet import Fernet, InvalidToken

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("bot-manager")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
OWNER_ID_RAW = os.environ.get("OWNER_ID", "").strip()
FERNET_KEY = os.environ.get("FERNET_KEY", "").strip()
DATA_DIR = Path(os.environ.get("DATA_DIR", "./data")).resolve()
MAX_UPLOAD_BYTES = 1 * 1024 * 1024
MAX_BOTS = 10
MAX_LOG_BYTES = 40_000
NAME_RE = re.compile(r"[^a-zA-Z0-9_-]+")

if not BOT_TOKEN or not OWNER_ID_RAW or not FERNET_KEY:
    raise SystemExit("Set BOT_TOKEN, OWNER_ID, and FERNET_KEY environment variables.")
try:
    OWNER_ID = int(OWNER_ID_RAW)
except ValueError:
    raise SystemExit("OWNER_ID must be your numeric Telegram user ID.")
try:
    cipher = Fernet(FERNET_KEY.encode())
except Exception as exc:
    raise SystemExit(f"FERNET_KEY is invalid. Generate one with Fernet.generate_key(): {exc}")

DATA_DIR.mkdir(parents=True, exist_ok=True)
BOTS_DIR = DATA_DIR / "bots"
BOTS_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "bots.json"

bot = Bot(BOT_TOKEN)
dp = Dispatcher()
processes: dict[str, asyncio.subprocess.Process] = {}
log_tails: dict[str, list[str]] = {}
restart_tasks: dict[str, asyncio.Task] = {}
pending: dict[int, dict[str, str]] = {}
locks: dict[str, asyncio.Lock] = {}


def load_db() -> dict[str, Any]:
    if not DB_PATH.exists():
        return {"bots": {}}
    try:
        data = json.loads(DB_PATH.read_text(encoding="utf-8"))
        if not isinstance(data.get("bots"), dict):
            return {"bots": {}}
        return data
    except (OSError, json.JSONDecodeError):
        log.exception("Could not read database; starting with an empty in-memory database.")
        return {"bots": {}}


db = load_db()


def save_db() -> None:
    temp = DB_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(db, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(DB_PATH)


def is_owner(user_id: int | None) -> bool:
    return user_id == OWNER_ID


def safe_name(filename: str) -> str:
    stem = Path(filename).stem[:40]
    cleaned = NAME_RE.sub("_", stem).strip("_-")
    return cleaned or "python_bot"


def bot_dir(bot_id: str) -> Path:
    return BOTS_DIR / bot_id


def bot_info(bot_id: str) -> dict[str, Any] | None:
    return db["bots"].get(bot_id)


def decrypt_env(info: dict[str, Any]) -> dict[str, str]:
    encrypted = info.get("env_enc", "")
    if not encrypted:
        return {}
    try:
        raw = cipher.decrypt(encrypted.encode()).decode("utf-8")
        obj = json.loads(raw)
        return {str(k): str(v) for k, v in obj.items()}
    except (InvalidToken, ValueError, json.JSONDecodeError):
        log.exception("Could not decrypt settings for bot %s", info.get("name"))
        return {}


def encrypt_env(env: dict[str, str]) -> str:
    return cipher.encrypt(json.dumps(env).encode("utf-8")).decode("utf-8")


def keyboard(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=data) for label, data in row]
        for row in rows
    ])


def main_menu() -> InlineKeyboardMarkup:
    return keyboard([
        [("➕ Добавить бота (.py)", "add"), ("🤖 Мои боты", "list")],
        [("ℹ️ Помощь", "help")],
    ])


def bot_menu(bot_id: str) -> InlineKeyboardMarkup:
    return keyboard([
        [("▶️ Запустить", f"startbot:{bot_id}"), ("⏹ Остановить", f"stopbot:{bot_id}")],
        [("🔄 Перезапустить", f"restartbot:{bot_id}"), ("📄 Логи", f"logs:{bot_id}")],
        [("⚙️ Переменные", f"settings:{bot_id}"), ("🗑 Удалить", f"delete:{bot_id}")],
        [("⬅️ К списку", "list"), ("🏠 Меню", "home")],
    ])


def status(bot_id: str) -> str:
    proc = processes.get(bot_id)
    if proc and proc.returncode is None:
        return "🟢 работает"
    return "🔴 остановлен"


def append_log(bot_id: str, line: str) -> None:
    lines = log_tails.setdefault(bot_id, [])
    lines.append(line.rstrip()[:1000])
    if len(lines) > 250:
        del lines[:-250]


async def drain_output(bot_id: str, stream: asyncio.StreamReader) -> None:
    while True:
        line = await stream.readline()
        if not line:
            break
        append_log(bot_id, line.decode("utf-8", errors="replace"))


async def stop_process(bot_id: str) -> str:
    task = restart_tasks.pop(bot_id, None)
    if task and task is not asyncio.current_task():
        task.cancel()
    proc = processes.get(bot_id)
    if not proc or proc.returncode is not None:
        processes.pop(bot_id, None)
        return "Бот уже остановлен."
    try:
        proc.terminate()
        await asyncio.wait_for(proc.wait(), timeout=5)
    except (ProcessLookupError, asyncio.TimeoutError):
        try:
            proc.kill()
            await asyncio.wait_for(proc.wait(), timeout=5)
        except (ProcessLookupError, asyncio.TimeoutError):
            pass
    processes.pop(bot_id, None)
    append_log(bot_id, "[manager] process stopped")
    return "Бот остановлен."


async def launch_process(bot_id: str) -> str:
    info = bot_info(bot_id)
    if not info:
        return "Бот не найден."
    if not (bot_dir(bot_id) / "main.py").is_file():
        return "Файл main.py не найден."
    current = processes.get(bot_id)
    if current and current.returncode is None:
        return "Бот уже запущен."
    env = {
        "PATH": os.environ.get("PATH", ""),
        "PYTHONUNBUFFERED": "1",
        "PYTHONIOENCODING": "utf-8",
        "HOME": str(bot_dir(bot_id)),
    }
    # Never pass manager token, encryption key, or owner ID to child bots.
    env.update(decrypt_env(info))
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-u", "main.py",
            cwd=str(bot_dir(bot_id)),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=(os.name != "nt"),
        )
    except Exception as exc:
        append_log(bot_id, f"[manager] launch failed: {exc}")
        return f"Не удалось запустить: {exc}"
    processes[bot_id] = proc
    append_log(bot_id, f"[manager] started pid={proc.pid}")
    asyncio.create_task(drain_output(bot_id, proc.stdout))

    async def monitor() -> None:
        try:
            code = await proc.wait()
            append_log(bot_id, f"[manager] process exited with code {code}")
            if processes.get(bot_id) is proc:
                processes.pop(bot_id, None)
            info_now = bot_info(bot_id)
            if info_now and info_now.get("auto_restart", True):
                delay = 3
                append_log(bot_id, f"[manager] auto-restart in {delay}s")
                await asyncio.sleep(delay)
                # Restart only if it was not intentionally stopped meanwhile.
                if bot_info(bot_id) and bot_info(bot_id).get("auto_restart", True) and bot_id not in processes:
                    await launch_process(bot_id)
        except asyncio.CancelledError:
            return

    restart_tasks[bot_id] = asyncio.create_task(monitor())
    return f"Запущен (PID {proc.pid})."


async def send_bot_list(message: Message | CallbackQuery) -> None:
    target = message.message if isinstance(message, CallbackQuery) else message
    if not db["bots"]:
        await target.answer("Пока нет ботов. Нажми «Добавить бота (.py)».", reply_markup=main_menu())
        return
    rows = []
    for bot_id, info in db["bots"].items():
        rows.append([(f"{info['name']} — {status(bot_id)}", f"open:{bot_id}")])
    rows.append([("➕ Добавить бота", "add"), ("🏠 Меню", "home")])
    await target.answer("Твои боты:", reply_markup=keyboard(rows))


@dp.message(CommandStart())
async def start_cmd(message: Message) -> None:
    if not is_owner(message.from_user.id if message.from_user else None):
        await message.answer("⛔ Доступ запрещён.")
        return
    await message.answer(
        "🤖 <b>Python Bot Manager</b>\n\n"
        "Загружай свои .py-боты, управляй запуском, смотри логи и настраивай переменные окружения.",
        reply_markup=main_menu(),
        parse_mode="HTML",
    )


@dp.callback_query()
async def callbacks(call: CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        await call.answer("Доступ запрещён", show_alert=True)
        return
    data = call.data or ""
    await call.answer()
    msg = call.message
    if not msg:
        return
    if data == "home":
        await msg.answer("Главное меню:", reply_markup=main_menu())
    elif data == "help":
        await msg.answer(
            "Как пользоваться:\n"
            "1. Нажми «Добавить бота» и отправь файл .py документом.\n"
            "2. Открой бота из списка.\n"
            "3. Задай переменные окружения в «Переменные» (например BOT_TOKEN).\n"
            "4. Нажми «Запустить».\n\n"
            "Загруженный Python-код выполняется на сервере. Загружай только доверенные файлы.",
            reply_markup=main_menu(),
        )
    elif data == "add":
        pending[call.from_user.id] = {"action": "upload"}
        await msg.answer("Отправь файл `.py` как документ. Максимум 1 MiB. Загружай только свой доверенный код.")
    elif data == "list":
        await send_bot_list(call)
    elif data.startswith("open:"):
        bot_id = data.split(":", 1)[1]
        info = bot_info(bot_id)
        if info:
            await msg.answer(f"🤖 {info['name']}\nСтатус: {status(bot_id)}\nАвтоперезапуск: {'вкл' if info.get('auto_restart', True) else 'выкл'}",
                             reply_markup=bot_menu(bot_id))
        else:
            await msg.answer("Бот не найден.", reply_markup=main_menu())
    elif data.startswith(("startbot:", "stopbot:", "restartbot:", "logs:", "settings:", "delete:")):
        action, bot_id = data.split(":", 1)
        info = bot_info(bot_id)
        if not info:
            await msg.answer("Бот не найден.", reply_markup=main_menu())
            return
        if action == "startbot":
            info["auto_restart"] = True
            save_db()
            result = await launch_process(bot_id)
            await msg.answer(result, reply_markup=bot_menu(bot_id))
        elif action == "stopbot":
            info["auto_restart"] = False
            save_db()
            result = await stop_process(bot_id)
            await msg.answer(result, reply_markup=bot_menu(bot_id))
        elif action == "restartbot":
            await stop_process(bot_id)
            info["auto_restart"] = True
            save_db()
            result = await launch_process(bot_id)
            await msg.answer(result, reply_markup=bot_menu(bot_id))
        elif action == "logs":
            text = "\n".join(log_tails.get(bot_id, [])[-50:]) or "Логов пока нет."
            if len(text) > 3900:
                text = text[-3900:]
            await msg.answer(f"<b>Последние логи: {info['name']}</b>\n<pre>{html_escape(text)}</pre>",
                             parse_mode="HTML", reply_markup=bot_menu(bot_id))
        elif action == "settings":
            await msg.answer(
                f"Настройки {info['name']}\n"
                f"Автоперезапуск сейчас: {'включён' if info.get('auto_restart', True) else 'выключен'}",
                reply_markup=keyboard([
                    [("➕/✏️ Задать переменную", f"setenv:{bot_id}")],
                    [("🔁 Переключить автоперезапуск", f"autorst:{bot_id}")],
                    [("⬅️ Назад", f"open:{bot_id}")],
                ]),
            )
        elif action == "delete":
            pending[call.from_user.id] = {"action": "delete_confirm", "bot_id": bot_id}
            await msg.answer(f"Для удаления отправь текст DELETE {bot_id}. Это удалит код и настройки.")
    elif data.startswith("setenv:"):
        bot_id = data.split(":", 1)[1]
        if bot_info(bot_id):
            pending[call.from_user.id] = {"action": "env_key", "bot_id": bot_id}
            await msg.answer("Отправь имя переменной (например BOT_TOKEN). Только A-Z, 0-9 и подчёркивание.")
    elif data.startswith("autorst:"):
        bot_id = data.split(":", 1)[1]
        info = bot_info(bot_id)
        if info:
            info["auto_restart"] = not info.get("auto_restart", True)
            save_db()
            await msg.answer(f"Автоперезапуск: {'включён' if info['auto_restart'] else 'выключен'}.",
                             reply_markup=bot_menu(bot_id))


def html_escape(text: str) -> str:
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


@dp.message(F.document)
async def document_handler(message: Message) -> None:
    if not is_owner(message.from_user.id if message.from_user else None):
        return
    doc: Document = message.document
    state = pending.get(message.from_user.id, {})
    if state.get("action") != "upload":
        await message.answer("Сначала нажми «Добавить бота (.py)» в меню.")
        return
    if not doc.file_name or not doc.file_name.lower().endswith(".py"):
        await message.answer("Нужен файл с расширением .py.")
        return
    if doc.file_size and doc.file_size > MAX_UPLOAD_BYTES:
        await message.answer("Файл больше лимита 1 MiB.")
        return
    if len(db["bots"]) >= MAX_BOTS:
        await message.answer(f"Достигнут лимит в {MAX_BOTS} ботов. Удали один перед добавлением.")
        return
    file = await bot.get_file(doc.file_id)
    content = await bot.download_file(file.file_path)
    raw = content.read(MAX_UPLOAD_BYTES + 1)
    if len(raw) > MAX_UPLOAD_BYTES:
        await message.answer("Файл больше лимита 1 MiB.")
        return
    bot_id = uuid.uuid4().hex[:10]
    name = safe_name(doc.file_name)
    folder = bot_dir(bot_id)
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "main.py").write_bytes(raw)
    db["bots"][bot_id] = {
        "name": name,
        "source_filename": doc.file_name,
        "env_enc": encrypt_env({}),
        "auto_restart": True,
        "created_at": int(time.time()),
    }
    save_db()
    pending.pop(message.from_user.id, None)
    await message.answer(f"Добавлен бот «{name}».\nТеперь открой «Мои боты», настрой переменные и запусти его.",
                         reply_markup=main_menu())


@dp.message(F.text)
async def text_handler(message: Message) -> None:
    if not is_owner(message.from_user.id if message.from_user else None):
        return
    user_id = message.from_user.id
    state = pending.get(user_id)
    if not state:
        return
    text = (message.text or "").strip()
    action = state.get("action")
    if action == "env_key":
        if not re.fullmatch(r"[A-Z_][A-Z0-9_]{0,63}", text):
            await message.answer("Неверное имя. Используй A-Z, цифры и _. Пример: BOT_TOKEN")
            return
        state["key"] = text
        state["action"] = "env_value"
        await message.answer(f"Теперь отправь значение для {text}. Сообщение с секретом лучше удалить после настройки.")
    elif action == "env_value":
        bot_id = state["bot_id"]
        info = bot_info(bot_id)
        if not info:
            pending.pop(user_id, None)
            await message.answer("Бот не найден.")
            return
        key = state["key"]
        if key in {"BOT_TOKEN_MANAGER", "FERNET_KEY", "OWNER_ID"}:
            await message.answer("Это имя переменной запрещено.")
            return
        env = decrypt_env(info)
        env[key] = text
        info["env_enc"] = encrypt_env(env)
        save_db()
        pending.pop(user_id, None)
        await message.answer(f"Переменная {key} сохранена в зашифрованном виде. Перезапусти дочернего бота, чтобы применить её.",
                             reply_markup=bot_menu(bot_id))
    elif action == "delete_confirm":
        bot_id = state["bot_id"]
        if text != f"DELETE {bot_id}":
            await message.answer(f"Подтверди удаление точным текстом: DELETE {bot_id}")
            return
        await stop_process(bot_id)
        db["bots"].pop(bot_id, None)
        save_db()
        import shutil
        shutil.rmtree(bot_dir(bot_id), ignore_errors=True)
        pending.pop(user_id, None)
        await message.answer("Бот удалён.", reply_markup=main_menu())


async def recover_autostart() -> None:
    # Resume bots marked for auto-restart after manager restarts.
    for bot_id, info in list(db["bots"].items()):
        if info.get("auto_restart", True):
            await launch_process(bot_id)


async def main() -> None:
    log.info("Starting manager; data directory: %s", DATA_DIR)
    await recover_autostart()
    try:
        await dp.start_polling(bot)
    finally:
        for bot_id in list(processes):
            await stop_process(bot_id)
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
