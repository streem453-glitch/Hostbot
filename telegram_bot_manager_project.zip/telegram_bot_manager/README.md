# Telegram Bot Manager (Python)

A private Telegram control panel that lets **one owner** upload Python bot files, start/stop/restart them, inspect recent logs, and configure per-bot environment variables.

## Important security warning

Uploaded `.py` files execute arbitrary Python code with the permissions of this service. A script can read/write files accessible to the service, use the network, consume CPU/RAM, and potentially expose data. **Only upload code you wrote or have carefully reviewed.** Do not use this as a public multi-user hosting service.

The manager:
- checks `OWNER_ID` on every interaction;
- limits uploads to 1 MiB and configured bot count;
- runs each child with a separate working directory and does not pass the manager's `BOT_TOKEN` or `FERNET_KEY` into child processes;
- encrypts stored per-bot environment settings using `FERNET_KEY`;
- does not make arbitrary uploaded code safe or fully sandboxed.

## Files

- `main.py` — Telegram manager and child-process supervisor.
- `requirements.txt` — dependencies.
- `render.yaml` — optional Render Blueprint (paid worker + persistent disk configuration).

## Run locally

Python 3.11+ recommended.

1. Create a Telegram bot with [@BotFather](https://t.me/BotFather).
2. Find your numeric Telegram user ID using a trusted ID bot or Telegram client.
3. Install dependencies:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
4. Generate a Fernet key:
   ```bash
   python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
   ```
5. Set environment variables before starting.

   **Windows PowerShell**
   ```powershell
   $env:BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
   $env:OWNER_ID="YOUR_NUMERIC_TELEGRAM_ID"
   $env:FERNET_KEY="PASTE_GENERATED_FERNET_KEY"
   $env:DATA_DIR="./data"
   python main.py
   ```

   **macOS/Linux**
   ```bash
   export BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
   export OWNER_ID="YOUR_NUMERIC_TELEGRAM_ID"
   export FERNET_KEY="PASTE_GENERATED_FERNET_KEY"
   export DATA_DIR="./data"
   python main.py
   ```

Keep the key and token private. If you lose `FERNET_KEY`, encrypted bot settings cannot be recovered.

## Telegram controls

- `/start` — open the control panel.
- **Add bot** — upload a `.py` file as a Telegram document. Its filename becomes the bot name.
- **My bots** — select a bot to start, stop, restart, view logs, or configure environment variables.
- **Settings** — add/update a variable such as `BOT_TOKEN` for that child bot. Values are stored encrypted.

For a child bot to use its token, its code should read it from an environment variable, e.g. `os.getenv("BOT_TOKEN")`.

## Deploy to Render

1. Push this project to a **private** GitHub repository.
2. In Render, create a Background Worker from the repository (or use the Blueprint).
3. Add `BOT_TOKEN`, `OWNER_ID`, and `FERNET_KEY` under Environment.
4. Attach a persistent disk mounted at `/var/data` if your plan supports it.
5. Deploy and inspect Logs.

The included `render.yaml` uses a paid `starter` worker because Render's free offerings do not provide an always-on Background Worker. Verify current pricing and plan availability in Render before deploying.

## Free 24/7 reality

There is no reliable promise of free, uninterrupted 24/7 execution for this design. Free hosting commonly sleeps, restarts, imposes CPU/RAM/time limits, or disallows persistent workers. When the manager sleeps or stops, child bots stop too. For reliable always-on use, a paid worker/VPS or a computer you keep running is typically needed. A free tier is suitable for testing, not a guarantee.

## Operational notes

- The manager stores uploaded code and encrypted settings under `DATA_DIR`.
- Keep your repository private and never commit `.env`, bot tokens, Fernet keys, or uploaded scripts.
- This is a single-owner convenience manager, not a hardened sandbox. For stronger isolation, use separate containers/VMs and OS-level resource/network controls.
